#pragma once

//void TestIterForward();
//void TestIterPartR();
//void TestIterForwardC();
//void TestIterPartCR();

void TestIter();
void TestIterInAlg();
//void TestRevIterInAlg();

